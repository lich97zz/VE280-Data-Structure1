#include <iostream>
#include "world_type.h"
#include <fstream>
#include <cstdlib>
#include "simulation.h"
using namespace std;

int main(int argc, char* argv[]){  
	project3(argc, argv);
    return 0;  
}  